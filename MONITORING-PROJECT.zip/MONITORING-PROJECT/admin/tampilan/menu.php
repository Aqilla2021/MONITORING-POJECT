<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
            <h1><a class="navbar-brand" href="?page=page/home"> Monitoring<p>Proyek&nbsp;</p> <br></a></h1>
          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header">MAIN NAVIGATION</li>
              <li class="treeview">
                <a href="?page=page/home">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
              </li>
			  <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Managemen Proyek</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="?page=page/kategori/index"><i class="fa fa-angle-right"></i> Kategori Proyek</a></li>
                  <li><a href="?page=page/proyek/index"><i class="fa fa-angle-right"></i>Data Proyek</a></li>
                  <li><a href="?page=page/pengajuanproyek/index&status=Baru"><i class="fa fa-angle-right"></i>Data Pengajuan Tender</a></li>
                  <li><a href="?page=page/pemenangproyek/index"><i class="fa fa-angle-right"></i>Data Pemenang Proyek</a></li>
                </ul>
              </li>

              <li class="treeview">
                <a href="?page=page/kontraktor/index">
                <i class="fa fa-users"></i>
                <span>Data Kontraktor</span>
                </a>
              </li>
             
              <li class="treeview">
                <a href="?page=page/pengawas/index">
                <i class="fa fa-users"></i>
                <span>Data Pengawas</span>
                </a>
              </li>
             
              <li class="treeview">
                <a href="#">
                <i class="fa fa-globe"></i> <span>Managemen Web</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="?page=page/banner/index"><i class="fa fa-angle-right"></i>Banner</a></li>
                  <li><a href="?page=page/kontak/kontak"><i class="fa fa-angle-right"></i> Kontak</a></li>
                  <li><a href="?page=page/kontak/caraperebutanproyek"><i class="fa fa-angle-right"></i> Cara Perebutan Proyek</a></li>
                </ul>
              </li>
               <li class="treeview">
                <a href="?page=page/keritikandansaran/index">
                <i class="fa fa-comments"></i>
                <span>Data Keritikan dan Saran</span>
                </a>
              </li>
              <li>
                <a href="?page=page/admin/index">
                <i class="fa fa-table"></i> <span>Admin</span>
              </li>
            
            </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>