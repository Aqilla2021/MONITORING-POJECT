<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					
					<div class="table-responsive bs-example widget-shadow">
						<h4>Data Proyek</h4>
						  <a class="btn btn-success" data-placement="bottom" data-toggle="tooltip" title="Tambah Proyek" href="?page=page/proyek/tambah">
                            <i class="fa fa-plus" style="font-size:15px;"></i>Proyek</a>  <p></p>
						<table class="table table-bordered"> 
							<thead>
                      <tr>
                        <th><center>No </center></th>
                        <th><center>Nama Proyek </center></th>
                        <th><center>Anggaran </center></th>
                        <th><center>Tahun Anggaran </center></th>
                        <th><center>Kategori </center></th>
                        <th><center>RAB </center></th>
                        <th><center>gambar Design </center></th>
                        <th><center>Status </center></th>
                        <th><center>Aksi</center></th>
                      </tr>
                  </thead>
                   
                    <tbody>
                       
                       <?php
                    $query1="select * from proyek as p,kategoriproyek as k where p.id_kategori=k.id_kategori";
                    
                    $tampil=$koneksi->query( $query1);
                
                     $no=0;
                     while($data=mysqli_fetch_array($tampil))
                    { $no++; ?>
                    <tr>
                    <td><center><?= $no;?></center></td>
                    <td><center><?= $data['namaproyek']; ?></center></td>
                    <td><center>Rp. <?= number_format($data['dana'],0,",",".");?></center></td>
                    <td><center><?= $data['tahunanggaran']; ?></center></td>

                    <td><center><?= $data['nama_kategori']; ?></center></td>
                    <td><center><a href="../img/rab/<?= $data['rab']; ?>" target="_BLANK" class="btn btn-primary"  /><i class="fa fa-cloud-download"></i></a></center></td>
                    <td><center><a href="../img/proyek/<?= $data['foto']; ?>" target="_BLANK" class="btn btn-primary"  /><i class="fa fa-cloud-download"></i></a></center></td>
                    
                    <td><center><?= $data['status']; ?></center></td>
                    <td>
                    	<center>
                    		<div id="thanks">
                    			<a class="btn btn-sm btn-primary" data-placement="bottom" data-toggle="tooltip" title="Edit proyek" href="?page=page/proyek/edit&id=<?= $data['id_proyek']; ?>">
                    				<i class="fa fa-check-square-o" style="font-size:15px;"></i></a>  
                        <a onclick="return confirm ('Yakin hapus .?');" class="btn btn-sm btn-danger tooltips" data-placement="bottom" data-toggle="tooltip" title="Hapus proyek" href="?page=page/proyek/hapus&id=<?= $data['id_proyek']; ?>"><span class="fa fa-trash-o" style="font-size:15px;"></a></div></center></td></tr>

                        <?php   
              } 
              ?>
						</table> 
					</div>
				</div>
			</div>
		</div>