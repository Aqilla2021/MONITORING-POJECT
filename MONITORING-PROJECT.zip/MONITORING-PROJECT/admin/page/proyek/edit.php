 <?php  $query1="select * from proyek as p,kategoriproyek as k where p.id_kategori=k.id_kategori and p.id_proyek='$_GET[id]'";
$tampil=$koneksi->query( $query1);
$dat=mysqli_fetch_array($tampil)
?> 
<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					
					
					<div class="row">
						<div class="form-three widget-shadow">
						<h3 class="title1">Edit Data Proyek :</h3>
							<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
								<input type="hidden" name="simpan">
								<input type="hidden" name="id" value="<?= $dat['id_proyek'];?>">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Nama Proyek</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="namaproyek" value="<?= $dat['namaproyek'];?>" >
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Kategori Proyek</label>
									<div class="col-sm-8">
										<select type="text" class="form-control" name="id_kategori" id="" >
											<option value="<?= $dat['id_kategori'];?>"><?= $dat['nama_kategori'];?></option>
											<?php
                    $tampil=$koneksi->query("select * from Kategoriproyek");
                
                     while($data=mysqli_fetch_array($tampil))
                    { if($data['id_kategori']==$dat['id_kategori']){}else{ ?>
											<option value="<?= $data['id_kategori'];?>"><?= $data['nama_kategori'];?></option>
										<?php }
									}
									?>
										</select> 
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Anggaran</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="dana" value="<?= $dat['dana'];?>" >
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Tahun Anggaran</label>
									<div class="col-sm-8">
										<select type="text" class="form-control" name="tahunanggaran"  >
											
											<option value="<?= $dat['tahunanggaran'];?>"><?= $dat['tahunanggaran'];?></option>
											<?php
for($i=date('Y'); $i>=date('Y')-5; $i-=1){
	if($i==$dat['tahunanggaran']){}else{ 
echo"<option value='$i'> $i </option>";
}
}
?>
										</select>
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Design Proyek</label>
									<div class="col-sm-8">
										<input type="file" class="form-control1" name="foto" id="" ><a href="../img/proyek/<?= $data['foto']; ?>" target="_BLANK" class="btn btn-primary"  /><i class="fa fa-cloud-download"></i></a></center>
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">RAB Proyek</label>
									<div class="col-sm-8">
										<input type="file" class="form-control1" name="rab" id="" ><a href="../img/rab/<?= $data['rab']; ?>" target="_BLANK" class="btn btn-primary"  /><i class="fa fa-cloud-download"></i></a></center>
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Latitude</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="latitude" value="<?= $dat['latitude'];?>"><a href="page/maps.php" target="_BLANK" class="btn btn-success">lihat titik Koordinat</a>
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Longitude</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="longitude" value="<?= $dat['longitude'];?>" >
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Waktu Pengerjaan (Bulan)</label>
									<div class="col-sm-8">
										<input type="number" class="form-control1" name="lamapekerjaan" value="<?= $dat['lamapekerjaan'];?>" >
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Keterangan</label>
									<div class="col-sm-8">
										<textarea type="text" class="form-control1" name="keterangan" id="" ><?= $dat['keterangan'];?></textarea>
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label"></label>
									<div class="col-sm-8"><button type="submit" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-plus" aria-hidden="true"></i>simpan</button>
										<a  href="?page=page/proyek/index"type="button" class="btn btn-warning btn-flat btn-pri btn- d"><i class="fa fa-mail-reply" aria-hidden="true"></i>Batal</a>
									</div>
									
								</div>

										
								
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<?php

    if (isset ($_POST['simpan'])){
        $file_name = $_FILES['foto']['name'];
        $tmp_name = $_FILES['foto']['tmp_name'];

        $file_name1 = $_FILES['rab']['name'];
        $tmp_name1 = $_FILES['rab']['tmp_name'];
        $namaproyek=addslashes($_POST['namaproyek']);
		$tahunanggaran = $_POST['tahunanggaran'];
        $id_kategori=addslashes($_POST['id_kategori']);
        $dana=addslashes($_POST['dana']);
        $latitude=addslashes($_POST['latitude']);
        $longitude=addslashes($_POST['longitude']);
        $lamapekerjaan=addslashes($_POST['lamapekerjaan']);
        $keterangan=addslashes($_POST['keterangan']);
if(empty($file_name)&&empty($file_name1)){
	$query_simpan =$koneksi->query( "UPDATE proyek SET 
        namaproyek='$namaproyek',
        id_kategori='$id_kategori',
        tahunanggaran='$tahunanggaran',
        dana='$dana',
        latitude='$latitude',
        longitude='$longitude',
        lamapekerjaan='$lamapekerjaan',
        keterangan='$keterangan'
         WHERE id_proyek='$_POST[id]'
        ");

}elseif(!empty($file_name)&&empty($file_name1)){
	$hapus= $koneksi->query("select * from proyek where id_proyek='$_POST[id]'");
    $tanggal_foto=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_foto['foto'];
    $hapus_foto="../img/proyek/$lokasi";
    unlink($hapus_foto);
    move_uploaded_file($_FILES['foto']['tmp_name'],'../img/proyek/'.$file_name);
	$query_simpan =$koneksi->query( "UPDATE proyek SET 
        namaproyek='$namaproyek',
        id_kategori='$id_kategori',
        tahunanggaran='$tahunanggaran',
        dana='$dana',
        latitude='$latitude',
        foto='$file_name',
        longitude='$longitude',
        lamapekerjaan='$lamapekerjaan',
        keterangan='$keterangan'
         WHERE id_proyek='$_POST[id]'
        ");
}elseif(empty($file_name)&&!empty($file_name1)){
	$hapus= $koneksi->query("select * from proyek where id_proyek='$_POST[id]'");
    $tanggal_foto=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_foto['rab'];
    $hapus_foto="../img/rab/$lokasi";
    unlink($hapus_foto);
    move_uploaded_file($_FILES['rab']['tmp_name'],'../img/proyek/'.$file_name1);
	$query_simpan =$koneksi->query( "UPDATE proyek SET 
        namaproyek='$namaproyek',
        id_kategori='$id_kategori',
        tahunanggaran='$tahunanggaran',
        dana='$dana',
        latitude='$latitude',
        rab='$file_name1',
        longitude='$longitude',
        lamapekerjaan='$lamapekerjaan',
        keterangan='$keterangan'
         WHERE id_proyek='$_POST[id]'");
}elseif(!empty($file_name)&&!empty($file_name1)){
	$hapus= $koneksi->query("select * from proyek where id_proyek='$_POST[id]'");
    $tanggal_foto=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_foto['rab'];
    $hapus_foto="../img/rab/$lokasi";
    unlink($hapus_foto);
    $lokasi1=$tanggal_foto['foto'];
    $hapus_foto1="../img/proyek/$lokasi1";
    unlink($hapus_foto1);
    move_uploaded_file($_FILES['foto']['tmp_name'],'../img/proyek/'.$file_name);
    move_uploaded_file($_FILES['rab']['tmp_name'],'../img/proyek/'.$file_name1);
	$query_simpan =$koneksi->query( "UPDATE proyek SET 
        namaproyek='$namaproyek',
        id_kategori='$id_kategori',
        tahunanggaran='$tahunanggaran',
        dana='$dana',
        latitude='$latitude',
        rab='$file_name1',
        foto='$file_name',
        longitude='$longitude',
        lamapekerjaan='$lamapekerjaan',
        keterangan='$keterangan'
         WHERE id_proyek='$_POST[id]'");

}
       
    if ($query_simpan) {
     echo"<script>alert('Data proyek Berhasil di Edit !!!'); window.location = '?page=page/proyek/index'</script>";
      }else{
      echo"<script>alert('Data proyek Gagal di Edit !!!'); window.location = '?page=page/proyek/tambah'</script>";
    }}?>