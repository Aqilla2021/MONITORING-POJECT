 <?php 
  $tampi=$koneksi->query("select * from pengajuanproyek where id_pengajuanproyek='$_GET[id]' ");

                     $no=0;
                     $dat=mysqli_fetch_array($tampi);

               
                      $tampil=$koneksi->query("select * from proyek as p,kategoriproyek as k where p.id_kategori=k.id_kategori and p.id_proyek='$dat[id_proyek]'");
                     $data=mysqli_fetch_array($tampil);
                      $ps=mysqli_num_rows($koneksi->query("select * from laporanproyek where id_pengajuanproyek='$dat[id_pengajuanproyek]' and status='Diterima'"));

                if($ps==$dat['lamapekerjaan']){
                    $query_simpan =$koneksi->query( "UPDATE proyek SET 
        status='Selesai'
         WHERE id_proyek='$dat[id_proyek]'
        ");
                }
                   
?> 
 <div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					
					<div class="table-responsive bs-example widget-shadow">
						<h4>Laporan Proyek <?= $data['namaproyek']?></h4>
            <div class="Responsive">
						<table class="table table-bordered"> 
							<thead>
                      <tr>
                         <td>No</td>
                            <td>Nama Proyek</td>
                            <td>Nama Kontraktor</td>
                            <td>Lama Pengerjaan</td>

                            <td>Harga Penawaran</td>
                            <td>Lapora Ke</td>
                            <td>Persentase</td>
                            <td>Anggran Keluar</td>
                            <td>Laporan</td>
                            <td>Status</td>
                            <td>Tanggal Laporan</td>
                            <td>Konfirmasi</td>
                      </tr>
                  </thead>
                   
                    <tbody>
                       
                        <?php
                   $p=mysqli_num_rows($koneksi->query("select * from laporanproyek where id_pengajuanproyek='$dat[id_pengajuanproyek]'"));
                    $tampi=$koneksi->query("select * from laporanproyek where id_pengajuanproyek='$_GET[id]'");
                
                     $no=0;
                     while($datt=mysqli_fetch_array($tampi))
                    {
    
                   

                     $tampill=$koneksi->query("select * from kontraktor where id_kontraktor='$dat[id_kontraktor]'");
                     $kontraktor=mysqli_fetch_array($tampill);
                
                    

                     $no++; ?>
                    <tr>
                    
                            <td><?= $no;?></td>
                            <?php if($no==1){?><td rowspan="<?= $p;?>"><?= $data['namaproyek'];?></td>
                            <td rowspan="<?= $p;?>"><?= $kontraktor['namapt'];?></td>
                            <td rowspan="<?= $p;?>"><?= $data['lamapekerjaan'];?></td>
                            <td rowspan="<?= $p;?>">Rp. <?= number_format($dat['hargapenawaran'],0,",",".");?></td>
                        <?php } ?>
                            <td><?= $datt['laporan_ke'];?></td>
                            <td><?= $datt['persentase'];?></td>
                            <td>Rp. <?= number_format($datt['anggarankeluar'],0,",",".");?></td>
                            <td><a href="../img/laporan/<?= $datt['dokumen']; ?>" target="_BLANK" class="btn btn-primary"  /><i class="fa fa-cloud-download"></i></a></td>
                            <td><?= $datt['status'];?></td>
                    <td><?= $datt['tgl_laporan'];?></td>
                    <td>
                    	<center>
                    		<div id="thanks">
                    			<a class="btn btn-sm btn-primary" data-placement="bottom" data-toggle="tooltip" title="Edit proyek" href="?page=page/laporanproyek/edit&id=<?= $datt['id_laporan']; ?>">
                    				<i class="fa fa-legal" style="font-size:15px;"></i></a><p><br></p></tr>

                        <?php   
              } 
              ?>
						</table> 
            </div>
					</div>
				</div>
			</div>
		</div>