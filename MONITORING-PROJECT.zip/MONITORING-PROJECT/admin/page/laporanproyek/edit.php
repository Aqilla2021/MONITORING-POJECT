 <?php 
  $tampi=$koneksi->query("select * from laporanproyek where id_laporan='$_GET[id]' ");
                
                     $no=0;
                     $dat=mysqli_fetch_array($tampi);
                    $tampil=$koneksi->query("select * from proyek as p,kategoriproyek as k where p.id_kategori=k.id_kategori and p.id_proyek='$dat[id_proyek]'");
                     $data=mysqli_fetch_array($tampil);

                     $tampill=$koneksi->query("select * from kontraktor where id_kontraktor='$dat[id_kontraktor]'");
                     $kontraktor=mysqli_fetch_array($tampill);
?> 
<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					
					
					<div class="row">
						<div class="form-three widget-shadow">
						<h3 class="title1">Konfirmasi Pengajuan Proyek :</h3>
							<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
								<input type="hidden" name="simpan">
								<input type="hidden" name="id" value="<?= $dat['id_laporan'];?>">
								<input type="hidden" name="id_pengajuanproyek" value="<?= $dat['id_pengajuanproyek'];?>">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Nama Proyek</label>
									<div class="col-sm-8">
										<input type="text" class="form-control" name="namaproyek" value="<?= $data['namaproyek'];?>" readonly >
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Kategori Proyek</label>
									<div class="col-sm-8">
											<input type="text" class="form-control" name="namaproyek" value="<?= $data['nama_kategori'];?>" readonly >
									
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Anggaran</label>
									<div class="col-sm-8">
										<input type="text" class="form-control" name="dana" value="<?= $data['dana'];?>" readonly>
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Lama Pengerjaan</label>
									<div class="col-sm-8">
										<input type="text" class="form-control" name="dana" value="<?= $data['lamapekerjaan'];?> Bulan" readonly>
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Laporan Ke</label>
									<div class="col-sm-8">
											<input type="text" class="form-control" name="namaproyek" value="<?= $dat['laporan_ke'];?>" readonly >
									
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Nama Kontaktor</label>
									<div class="col-sm-8">
											<input type="text" class="form-control" name="namaproyek" value="<?= $kontraktor['namapt'];?>" readonly >
									
									</div>
									
								</div>
								
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Laporan</label>
									<div class="col-sm-8">
											<a href="../img/laporan/<?= $dat['laporan']; ?>" target="_BLANK" class="btn btn-primary"  /><i class="fa fa-cloud-download"></i></a>
									
									</div>
									
								</div>
								
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Konfirmasi</label>
									<div class="col-sm-8">
										<select type="text" class="form-control" name="status" id="" >
											<option>Pilih</option>
											<option value="Diterima">Diterima</option>
											<option value="Ditolak">Ditolak</option>
										
										</select> 
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label"></label>
									<div class="col-sm-8"><button type="submit" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-check" aria-hidden="true"></i>Konfirmasi</button>
										<a  href="?page=page/pengajuanproyek/index"type="button" class="btn btn-warning btn-flat btn-pri btn- d"><i class="fa fa-mail-reply" aria-hidden="true"></i>Batal</a>
									</div>
									
								</div>

										
								
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<?php

    if (isset ($_POST['simpan'])){
       
	$query_simpan =$koneksi->query( "UPDATE laporanproyek SET 
        status='$_POST[status]'
         WHERE id_laporan='$_POST[id]'
        ");

    if ($query_simpan) {
     echo"<script>alert('Data Berhasil di konfirmasi !!!'); window.location = '?page=page/laporanproyek/index&id=$_POST[id_pengajuanproyek]'</script>";
      }else{
      echo"<script>alert('Data gagal dikonfirmasi !!!'); window.location = '?page=page/penjuanproyek/index&id=$_POST[id_pengajuanproyek]'</script>";
    }}?>