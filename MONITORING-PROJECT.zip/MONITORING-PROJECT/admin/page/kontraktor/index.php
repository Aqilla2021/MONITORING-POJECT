<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					
					<div class="table-responsive bs-example widget-shadow">
						<h4>Data Kontraktor</h4>
						
						<table class="table table-bordered"> 
							<thead>
                      <tr>
                        <th><center>No </center></th>
                        <th><center>Nama PT </center></th>
                        <th><center>Alamat </center></th>
                        <th><center>NPWP </center></th>
                        <th><center>NIB</center></th>
                        <th><center>IUP </center></th>
                        <th><center>AKTA </center></th>
                        <th><center>Status </center></th>
                        <th><center>Aksi</center></th>
                      </tr>
                  </thead>
                   
                    <tbody>
                       
                       <?php
                    $query1="select * from kontraktor";
                    
                    $tampil=$koneksi->query( $query1);
                
                     $no=0;
                     while($data=mysqli_fetch_array($tampil))
                    { $no++; ?>
                    <tr>
                    <td><center><?= $no;?></center></td>
                    <td><center><?= $data['namapt']; ?></center></td>
                    <td><center><?= $data['alamat']; ?></center></td>

                    <td><center><a href="../img/npwp/<?= $data['npwp']; ?>" target="_BLANK" class="btn btn-primary"  /><i class="fa fa-cloud-download"></i></a></center></td>
                    <td><center><a href="../img/nib/<?= $data['nib']; ?>" target="_BLANK" class="btn btn-primary"  /><i class="fa fa-cloud-download"></i></a></center></td>
                    <td><center><a href="../img/iup/<?= $data['iup']; ?>" target="_BLANK" class="btn btn-primary"  /><i class="fa fa-cloud-download"></i></a></center></td>
                    <td><center><a href="../img/akta/<?= $data['akta']; ?>" target="_BLANK" class="btn btn-primary"  /><i class="fa fa-cloud-download"></i></a></center></td>
                    <td><center><?= $data['status']; ?></center></td>
                    <td>
                    	<center>
                    		<div id="thanks">
                    			<a class="btn btn-sm btn-primary" data-placement="bottom" data-toggle="tooltip" title="Edit kontraktor" href="?page=page/kontraktor/view&id=<?= $data['id_kontraktor']; ?>">
                    				<i class="fa fa-search" style="font-size:15px;"></i></a>  
                        <a onclick="return confirm ('Yakin hapus .?');" class="btn btn-sm btn-danger tooltips" data-placement="bottom" data-toggle="tooltip" title="Hapus kontraktor" href="?page=page/kontraktor/hapus&id=<?= $data['id_kontraktor']; ?>"><span class="fa fa-trash-o" style="font-size:15px;"></a></div></center></td></tr>

                        <?php   
              } 
              ?>
						</table> 
					</div>
				</div>
			</div>
		</div>