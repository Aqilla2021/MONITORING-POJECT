 <?php  $query1="select * from profil where id_profil='1'";
$tampil=$koneksi->query( $query1);
$data=mysqli_fetch_array($tampil)
?> 
<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					
					
					<div class="row">
						<div class="form-three widget-shadow">
						<h3 class="title1">Tambah Data kontak :</h3>
							<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
								<input type="hidden" name="simpan">
								<input type="hidden" name="id" value="<?= $data['id_profil'];?>">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Cara Perebutan Proyek</label>
									<div class="col-sm-8">
										<textarea type="text" id="idsas" class="form-control1" name="caraperebutanproyek" ><?= $data['caraperebutanproyek'];?></textarea>
									
									
						
  <script src="ckeditor/ckeditor.js"></script>
    <script type="text/javascript">
      CKEDITOR.replace( 'idsas',{height: 200} );
    </script>
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Link Video Youtube</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="embed" value="<?= $data['embed'];?>">
									</div>
									
								</div>
								
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">cover</label>
									<div class="col-sm-8">
										<img src="../img/kontak/<?= $data['cover'];?>" width="300px">
										<input type="file" class="form-control1" name="cover">
									</div>
									
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label"></label>
									<div class="col-sm-8"><button type="submit" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-plus" aria-hidden="true"></i>simpan</button>
										<a  href="?page=page/kontak/index"type="button" class="btn btn-warning btn-flat btn-pri btn- d"><i class="fa fa-mail-reply" aria-hidden="true"></i>Batal</a>
									</div>
									
								</div>

										
								
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<?php 

if (isset($_POST['simpan'])){

  $cover   = $_FILES['cover']['name'];
  if (empty($cover)){
    $koneksi->query("UPDATE profil SET 
                    caraperebutanproyek     = '$_POST[caraperebutanproyek]',
                    embed = '$_POST[embed]'
                    WHERE id_profil = '$_POST[id]'");
}else{


    $hapus= $koneksi->query("select * from profil where profil='$_POST[id]'");
    $tanggal_cover=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_cover['cover'];
    $hapus_cover="../img/kontak/$lokasi";
    unlink($hapus_cover);
    move_uploaded_file($_FILES['cover']['tmp_name'],'../img/kontak/'.$cover);
    $koneksi->query("UPDATE profil SET 
                    caraperebutanproyek     = '$_POST[caraperebutanproyek]',
                    embed = '$_POST[embed]',
                    cover  = '$cover'
                    WHERE id_profil= '$_POST[id]'");
  }
echo"<script>alert('Data Berhasil di Ubah!!!'); window.location = '?page=page/kontak/caraperebutanproyek'</script>";
    }



 ?>