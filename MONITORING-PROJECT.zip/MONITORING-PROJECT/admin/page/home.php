<?php

$proyekbaru =mysqli_num_rows($koneksi->query("select * from proyek where status='Baru'"));
$proyekonprogr =mysqli_num_rows($koneksi->query("select * from proyek where status='On Progress'"));
$proyeksel =mysqli_num_rows($koneksi->query("select * from proyek where status='Selesai'"));
$pkon =mysqli_num_rows($koneksi->query("select * from kontraktor"));
?>	<div id="page-wrapper">
			<div class="main-page">
			<div class="col_3">
        	
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-laptop user1 icon-rounded" style="background-color: yellowgreen;"></i>
                    <div class="stats">
                      <h5><strong><?= $proyekbaru?></strong></h5>
                      <span>Proyek Baru <span style="color:transparent;">abs</span></span>
                    </div>
                </div>
        	</div>
            <div class="col-md-3 widget widget1">
                <div class="r3_counter_box">
                    <i class="pull-left fa fa-laptop user1 icon-rounded" style="background-color: blue;"></i>
                    <div class="stats">
                      <h5><strong><?= $proyekonprogr?></strong></h5>
                      <span>Proyek On Progress </span>
                    </div>
                </div>
            </div> 
            <div class="col-md-3 widget widget1">
                <div class="r3_counter_box">
                    <i class="pull-left fa fa-laptop user1 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?= $proyeksel?></strong></h5>
                      <span>Proyek Selesai <span style="color:transparent;">abs</span></span>
                    </div>
                </div>
            </div>
        	<div class="col-md-3 widget">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-users dollar2 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?= $pkon;?></strong></h5>
                      <span>Total Kontraktor <span style="color:transparent;">abs</span></span>
                    </div>
                </div>
        	 </div>
        	<div class="clearfix"> </div>
		</div>
		
		<div class="row-one widgettable">
			
<script src="http://code.jquery.com/jquery-1.10.2.min.js" type="text/javascript"></script>
    <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyA7IZt-36CgqSGDFK8pChUdQXFyKIhpMBY&sensor=true" type="text/javascript"></script>


<script>    
    var marker;
    function initialize() {  
        // Variabel untuk menyimpan informasi (desc)
        var infoWindow = new google.maps.InfoWindow;
        //  Variabel untuk menyimpan peta Roadmap
        var mapOptions = {
            mapTypeId: google.maps.MapTypeId.ROADMAP
        } 
        // Pembuatan petanya
        var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);      
        // Variabel untuk menyimpan batas kordinat
        var bounds = new google.maps.LatLngBounds();
        // Pengambilan data dari database
        <?php
            $query = $koneksi->query("SELECT * FROM proyek");
            while ($data = mysqli_fetch_array($query)) {
                $nama    =$data['namaproyek'];
                $lat    =$data['latitude'];
                $lon    =$data['longitude'];
                echo ("addMarker($lat, $lon, '$nama');\n");                        
            }    
        ?> 
        // Proses membuat marker 
        function addMarker(lat, lng, info) {
            var lokasi = new google.maps.LatLng(lat, lng);
            bounds.extend(lokasi);
            var marker = new google.maps.Marker({
                map: map,
                position: lokasi
            });       
            map.fitBounds(bounds);
            bindInfoWindow(marker, map, infoWindow, info);
         }        
        // Menampilkan informasi pada masing-masing marker yang diklik
        function bindInfoWindow(marker, map, infoWindow, html) {
            google.maps.event.addListener(marker, 'click', function() {
            infoWindow.setContent(html);
            infoWindow.open(map, marker);
          });
        }
    }
    google.maps.event.addDomListener(window, 'load', initialize);
</script>
<div id="map-canvas"  style="height:380px;"></div>
		</div>
			
			</div>
		</div>