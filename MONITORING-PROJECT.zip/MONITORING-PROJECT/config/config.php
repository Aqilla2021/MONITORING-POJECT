<?php
$koneksi = new mysqli ("localhost","root","","monitoring-project");
?>

<!-- end -->